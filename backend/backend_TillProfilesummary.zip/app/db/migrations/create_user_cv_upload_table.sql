-- Migration: Create user_cv_upload table
-- Stores complete CV upload data: file metadata, extracted text, contact info,
-- detected sections, and LLM future-role predictions.
-- One row per upload event.

CREATE TABLE IF NOT EXISTS user_cv_upload (
    id                   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id           TEXT        NOT NULL,
    candidate_id         UUID,

    -- File metadata
    filename             TEXT        NOT NULL,
    content_type         TEXT        NOT NULL DEFAULT 'application/octet-stream',
    file_size            INTEGER     NOT NULL,
    content_hash         TEXT        NOT NULL,

    -- Extracted text
    raw_text             TEXT        NOT NULL,
    work_experience      JSONB       NOT NULL DEFAULT '{"formatted_text": "", "entries": []}',
    -- Note: work_experience.entries contains structured array from LLM with fields:
    --   job_title, company, location, employment_type, start_date, end_date, is_current,
    --   duration, responsibilities[], achievements[], technologies[], tools[], projects[],
    --   keywords[], raw_text
    education            JSONB       NOT NULL DEFAULT '{"formatted_text": "", "entries": []}',
    -- Note: education.entries contains structured array from LLM with fields:
    --   institution, degree, field_of_study, location, start_date, end_date, 
    --   is_current, gpa, honors[], raw_text

    -- Structured extractions (JSONB)
    contact_info         JSONB       NOT NULL DEFAULT '{}',
    sections             JSONB       NOT NULL DEFAULT '{}',
    sections_found       JSONB       NOT NULL DEFAULT '[]',
    warnings             JSONB       NOT NULL DEFAULT '[]',

    -- Computed fields
    years_of_experience  NUMERIC(5,2),
    location             TEXT        NOT NULL DEFAULT '',

    -- LLM output
    future_roles_data    JSONB,

    -- Timestamps
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index on session_id for lookups by session
CREATE INDEX IF NOT EXISTS ix_user_cv_upload_session_id
    ON user_cv_upload (session_id);

-- Index on candidate_id for lookups by user
CREATE INDEX IF NOT EXISTS ix_user_cv_upload_candidate_id
    ON user_cv_upload (candidate_id);

-- Index on content_hash for duplicate detection
CREATE INDEX IF NOT EXISTS ix_user_cv_upload_content_hash
    ON user_cv_upload (content_hash);

-- Index on created_at for chronological queries
CREATE INDEX IF NOT EXISTS ix_user_cv_upload_created_at
    ON user_cv_upload (created_at DESC);

-- Dedicated JSONB columns for tools, skills, and certifications
-- (extracted from future_roles_data for direct queryability)
ALTER TABLE user_cv_upload ADD COLUMN IF NOT EXISTS tools_and_technologies JSONB NOT NULL DEFAULT '{}';
ALTER TABLE user_cv_upload ADD COLUMN IF NOT EXISTS core_skills JSONB NOT NULL DEFAULT '{}';
ALTER TABLE user_cv_upload ADD COLUMN IF NOT EXISTS certifications JSONB NOT NULL DEFAULT '[]';

-- Migrate work_experience from TEXT to JSONB (idempotent — only runs if column is still TEXT)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'user_cv_upload'
          AND column_name = 'work_experience'
          AND data_type = 'text'
    ) THEN
        ALTER TABLE user_cv_upload
            ALTER COLUMN work_experience DROP DEFAULT;

        ALTER TABLE user_cv_upload
            ALTER COLUMN work_experience
            SET DATA TYPE JSONB
            USING CASE
                WHEN work_experience IS NULL THEN '{"formatted_text": "", "entries": []}'::jsonb
                ELSE jsonb_build_object(
                    'formatted_text', work_experience,
                    'entries', '[]'::jsonb
                )
            END;

        ALTER TABLE user_cv_upload
            ALTER COLUMN work_experience
            SET DEFAULT '{"formatted_text": "", "entries": []}'::jsonb;
    END IF;
END $$;
